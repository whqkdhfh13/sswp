package helloworld;

import java.util.ArrayList;

public class Helloworld {
	
	private static boolean loopgame = false;

	public static void main(String[] args) {
		
		while(loopgame) {
			 
		}
		
	}

}